<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
  $user = $_SESSION['user'];
}
?>
<html>

<head>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="cart.css">

  <style>
    body {
      color: #a52a2a;
      background-color: floralwhite;

    }

    a:link {
      color: #a52a2a;
      ;
      text-decoration: none;
    }

    body {

      background-color: floralwhite;

    }

    .row {

      left: 0;

      right: 0;

      top: 0;

      display: flex;

    }

    .co {

      left: 0;

      right: 0;

      top: 0;

      flex: 0%;

    }



    .nav {

      text-align: right;

    }
  </style>

</head>

<body>

  <div class="container">
    <div class="">
      <nav>
        <div class="logo">
          <a href="index.php">
            <bold>MTAD</bold>
          </a>
        </div>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="events.php">Events</a></li>

          <li><a href="cart.php">Cart</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
        <div class="buttons">

          <?php if ($user == '') {
          ?>
            <a href="login.php" class="btn">Log in /Register</a>
          <?php } else { ?>
            <a href="logout.php" class="btn">Logout</a>
          <?php } ?>
        </div>
      </nav>

      <header>
        <div class="row">
          <div class="co">
            <img class="h_img" src="images/w1.jpg">
          </div>
        </div>
      </header>

      <div class="main-banner">

      </div>


      <br> <br>

      <?php if ($user == '') {
      ?>
        <br> <br>
        <center>
          <h2>Login to view your cart</h2><br> <br>
        </center>

      <?php } else { ?>
        <center>
          <h1> Cart</h1>
        </center>
        <br><br><br>

        <section id="cart-container">
          <table>
            <thead class="thead">
              <tr>
                <th>Event Name</th>
                <th>Quantity</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody class="tbody">

              <?php
              $conn = mysqli_connect("localhost", "root", "", "mtad");
              $sql = "select * from cart where username='$user'";
              $result = mysqli_query($conn, $sql);
              $total = 0;
              while ($row = mysqli_fetch_assoc($result)) {
                $total = $total + $row['price'];
              ?>
                <tr>
                  <td><?php echo $row['event_name'] ?></td>
                  <td><?php echo $row['quantity'] ?></td>
                  <td><?php echo $row['price'] ?></td>
                </tr>

              <?php } ?>

              <td colspan="4"> </td>
              <tr class="totalRow">
                <td colspan="5"><?php echo 'Total amount: ' . $total . ' SR' ?></td>
              </tr>
            </tbody>
          </table>
          <?php
          if ($total > 0) { ?>
            <button onclick="location.href='payment.php'">Checkout</button>
          <?php } ?>

        </section>
      <?php } ?>


      <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>


</html>