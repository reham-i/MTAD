<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
  $user = $_SESSION['user'];
}
$sql = "delete from cart where username='$user'";
$connection = mysqli_connect("localhost", "root", "", "mtad");
$result = mysqli_query($connection, $sql);
if ($result)
    echo "<script>alert('Paid successfully'); 
    location.href='cart.php'</script>";
else
    echo "<script>alert('pay error'); 
    location.href='cart.php';</script>";

    ?>