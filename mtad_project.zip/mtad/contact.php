<?php
session_start();
$user ="";
if(isset($_SESSION['user'])){
$user = $_SESSION['user'];
}
?>
<html>
<head>


  <meta charset="UTF-8">
  
    <link rel="stylesheet" href="style.css">
<style>

    body{
      color: #a52a2a;
      background-color: floralwhite;
      
    }
    a:link{
  color:#a52a2a;;
  text-decoration: none;
}
.row {

left:0;

right:0;

top:0;

display:flex;

}

.co {

left:0;

right:0;

top:0;

flex:0%;

}
  </style>
</head>

<body>

  
  <div class="container">
    <div class="border">
    <nav>
      <div class="logo">
        <a href="index.php"><bold>MTAD</bold></a>
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        
        <li><a href="cart.php">Cart</a></li>
        <li><a href="faq.php" >FAQ</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <div class="buttons">
        
      <?php if($user==''){
        ?>
        <a href="login.php" class="btn">Log in /Register</a>
        <?php } else {?>
          <a href="logout.php" class="btn">Logout</a>
          <?php }?>
    </div>
    </nav>
    <header>
      <div class="row">
        <div class="co">
          <img class="h_img" src="images/w1.jpg">
        </div>
      </div>
    </header>
    <br>
<h1 style='text-align:center;'>You can conatact Us:</h1>
<br>
<br>
<br>
<br>
<p>
<a href="mailto:mtad.company@gmail.com">
<img src="images/c1.jpg"
height="50" width="50" alt="E-mail"> &nbsp <bold>"mailto:mtad.company@gmail.com"</bold> </a>
</p>
<br>
<p style='color:#a52a2a;'>
<img src="images/c2.jpg"
height="50" width="50" alt="+966354299841">&nbsp  <bold>+966354299841</bold>
</p>
<br>
<p> 

<a href="https://twitter.com/mtad.company">
<img src="images/c3.jpg"
height="50" width="50" alt="x"> &nbsp <bold>"https://twitter.com/mtad.company"</bold> </a>
</p>
<br>
<p>

<a href="https://www.instagram.com/mtad.company">
<img src="images/c4.jpg"
height="50" width="50" alt="instagram"> &nbsp <bold>"https://www.instagram.com/mtad.company"</bold> </a> 
</p>  
<div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>
</html>