<?php
session_start();
$user ="";
if(isset($_SESSION['user'])){
$user = $_SESSION['user'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <style>
  body{
    color: #9c6d14;
  }
  .container{
    width: 100%;
    height: 100vh;
    background-image: url('images/w2.jpg');
    background-position: center;
    background-size: cover;
    padding-top: 35px;
    padding-left: 8%;
    padding-right: 8%;
  }</style>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title>Welcome</title>

  <!---Custom Css File!--->
    <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">
    
    <nav>
      <div class="logo">
        <a href="index.php"><bold>MTAD</bold></a>
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        
        <li><a href="cart.php">Cart</a></li>
        <li><a href="faq.php" >FAQ</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <div class="buttons">
        
      <?php if($user==''){
        ?>
        <a href="login.php" class="btn">Log in /Register</a>
        <?php } else {?>
          <a href="logout.php" class="btn">Logout</a>
          <?php }?>
    </div>
    </nav>
    <div class="content">
      <h2>Hello,<br><?php echo $user?></h2>
      <p>More Than A Dessert.</p>
    </div>
    <div class="link">
      <a href="events.php" class="hire">Explore Events</a>
    </div>
</div>

</body>
</html>