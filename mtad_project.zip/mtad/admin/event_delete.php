<?php
$id = $_GET['id'];
$sql = "delete from events where id=$id";
$connection = mysqli_connect("localhost", "root", "", "mtad");
$result = mysqli_query($connection, $sql);
if ($result)
    echo "<script>alert('Event deleted'); 
    location.href='event_manage.php'</script>";
else
    echo "<script>alert('deleted error'); 
    location.href='event_manage.php';</script>";

    ?>