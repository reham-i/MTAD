<?php
$id = $_GET['id'];
$conn = mysqli_connect("localhost", "root", "", "mtad");
$sql = "SELECT * from `events` where id =$id";
$result = mysqli_query($conn, $sql);
$event = mysqli_fetch_assoc($result);
$img = $event['image'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $ticket_price = $_POST['ticket_price'];
    if (file_exists($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
        $img = $_FILES['file']['tmp_name'];
        $img = base64_encode(file_get_contents(addslashes($img)));
    }

    $sql = "update events set name='$name', ticket_price=$ticket_price ,image = '$img' where id = $id";
    $result = mysqli_query($conn, $sql);
    if ($result)
        echo "<script>alert('Event updated'); 
       location.href='event_manage.php'</script>";
    else {
        echo "<script>alert('update error');</script>";
    }
}

?>

?>
<html>

<head>
    <title>ADMIN</title>
    <link rel="stylesheet" type="text/css" href="../info.css">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container">

        <nav>
            <div class="logo">
                <a href="event_manage.php">
                    <bold>MTAD</bold>
                </a>
            </div>
            <ul>
                <li><a href="event_manage.php">Events Management</a></li>
                <li><a href="event_add.php">Add event</a></li>
            </ul>
            <div class="buttons">

                <a href="../index.php" class="btn">Logout</a>

            </div>
        </nav>

        <header>
            <div class="row">
                <div class="co">
                    <img class="h_img" src="../images/w1.jpg">
                </div>
            </div>
        </header>
        <br>

        <form method="post" action="event_update.php?id=<?php echo $id ?>" enctype="multipart/form-data">
            <h1>Update event</h1><br> <br>
            <p> Event name: </p>
            <p> <input type="text" name="name" value="<?php echo $event['name'] ?>" placeholder="" required></p> <br>

            <p> Ticket price: </p>
            <p><input type="text" name="ticket_price" value="<?php echo $event['ticket_price'] ?>" placeholder="" required></p> <br>

            <p> Event image: (optional)</p>
            <p><input type="file" name="file" accept="image/*"></p> <br>
            <input type="submit" value="Update" id="button" />
        </form>
        </p>

        <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>

</html>