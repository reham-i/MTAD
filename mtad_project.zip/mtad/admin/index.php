<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
extract($_POST);
$conn = mysqli_connect( "localhost","root","","mtad");
$sql = "SELECT  `username`, `password` FROM `admin` WHERE username = '$username' && password ='$password'";
$result = mysqli_query($conn, $sql);

if ($result->num_rows === 0)
    echo "<script>alert('Invalid username or password');</script>";
else {
    header('Location: event_manage.php');
}
}
?>
<html>

<head>
  <title>ADMIN</title>
  <link rel="stylesheet" type="text/css" href="../info.css">
  <link rel="stylesheet" href="../style.css">
</head>

<body>
  <div class="container">

    <nav>
      <div class="logo">
        <a href="index.php">
          <bold>MTAD</bold>
        </a>
      </div>
  
      <div class="buttons">

      </div>
    </nav>

    <header>
      <div class="row">
        <div class="co">
          <img class="h_img" src="../images/w1.jpg">
        </div>
      </div>
    </header>
    <br>
    <form method="post" action="index.php">
      <h1>Admin Login</h1><br> <br>
      <p> Username: </p>
      <p> <input type="text" name="username" placeholder="" required></p> <br>

      <p> Password: </p>
      <p><input type="password" name="password" placeholder="" autocomplete="new-password" required></p> <br>
      <input type="submit" value="Login" id="button" />
         </form>
    </p>

</body>

</html>