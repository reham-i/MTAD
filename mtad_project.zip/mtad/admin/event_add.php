<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $ticket_price = $_POST['ticket_price'];
    $img = $_FILES['file']['tmp_name'];
    $img = base64_encode(file_get_contents(addslashes($img)));
    $conn = mysqli_connect("localhost", "root", "", "mtad");
    $sql = "INSERT INTO `events`(`name`, `image`, `ticket_price`) VALUES ('$name','$img',$ticket_price)";
    $result = mysqli_query($conn, $sql);

    if ($result)
        echo "<script>alert('Added successfully'); 
location.href='event_manage.php'</script>";
    else {
        echo "<script>alert('Add error');</script>";
    }
}


?>
<html>

<head>
    <title>ADMIN</title>
    <link rel="stylesheet" type="text/css" href="../info.css">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container">

        <nav>
            <div class="logo">
                <a href="event_manage.php">
                    <bold>MTAD</bold>
                </a>
            </div>
            <ul>
                <li><a href="event_manage.php">Events Management</a></li>
                <li><a href="event_add.php">Add event</a></li>
            </ul>
            <div class="buttons">

                <a href="../index.php" class="btn">Logout</a>

            </div>
        </nav>

        <header>
            <div class="row">
                <div class="co">
                    <img class="h_img" src="../images/w1.jpg">
                </div>
            </div>
        </header>
        <br>
        <form method="post" action="event_add.php" enctype="multipart/form-data">
            <h1>Add event</h1><br> <br>
            <p> Event name: </p>
            <p> <input type="text" name="name" placeholder="" required></p> <br>

            <p> Ticket price: </p>
            <p><input type="text" name="ticket_price" placeholder="" required></p> <br>

            <p> Event image: </p>
            <p><input type="file" name="file" accept="image/*" required></p> <br>
            <input type="submit" value="Add" id="button" />
        </form>
        </p>

        <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>

</html>