<html>

<head>
  <link rel="stylesheet" href="../style.css">

  <style>
    body {
      color: #a52a2a;
      background-color: floralwhite;

    }

    a:link {
      color: #a52a2a;
      ;
      text-decoration: none;
    }

    body {

      background-color: floralwhite;

    }

    .row {

      left: 0;

      right: 0;

      top: 0;

      display: flex;

    }

    .co {

      left: 0;

      right: 0;

      top: 0;

      flex: 0%;

    }



    .nav {

      text-align: right;

    }
  </style>

</head>

<body>

  <div class="container">
    <div class="">
      <nav>
        <div class="logo">
          <a href="event_manage.php">
            <bold>MTAD</bold>
          </a>
        </div>
        <ul>
          <li><a href="event_manage.php">Events Management</a></li>
          <li><a href="event_add.php">Add event</a></li>
        </ul>
        <div class="buttons">

          <a href="../index.php" class="btn">Logout</a>

        </div>
      </nav>

      <header>
        <div class="row">
          <div class="co">
            <img class="h_img" src="../images/w1.jpg">
          </div>
        </div>
      </header>

      <div class="main-banner">

      </div>


      <br> <br>

      <div class="main-white-button" style="text-align:center;">

        <h1> Event managment</h1>
        <br><br><br>


        <div class="event">



          <div style="display:inline-flex; flex-wrap:wrap;">
            <?php
            $conn = mysqli_connect("localhost", "root", "", "mtad");
            $sql = "select * from events order by id desc";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
            
            ?>
              <div class="event_div">
                  <img src="<?php echo 'data:image/jpeg;base64,' . $row['image'] ?>" width="250" height="250" style="border-radius: 40%;" alt="">
                <br> <br>
                <h2><?php echo $row['name'] ?></h2>
                <br>
                <h3 style="color:black"><?php echo 'Ticket price: '.$row['ticket_price'].' SR'?></h3>
                <br>
                <br>
                <p class="a_1">
                <a href="event_update.php?id=<?php echo $row["id"]; ?>">Update</a>
                </p>
                <br>
                <p class="a_2">
                <a href="event_delete.php?id=<?php echo $row["id"]; ?>" onclick="return confirm('Are you sure delete event?')">Delete</a>
                </p>
              </div>

            <?php } ?>

          </div>


    <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>


</html>