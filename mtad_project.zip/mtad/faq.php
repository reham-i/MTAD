<?php
session_start();
$user ="";
if(isset($_SESSION['user'])){
$user = $_SESSION['user'];
}
?>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
        
        <style>
         body{
      color: #a52a2a;
      background-color: floralwhite;
    }
    a:link{
  color:#a52a2a;;
  text-decoration: none;
}
h4,h2{
    position: relative;
      text-align: center;
      top:100px;
}
.row {

left:0;

right:0;

top:0;

display:flex;

}

.co {

left:0;

right:0;

top:0;

flex:0%;

}
        </style>
    </head>


    <div class="container">
        <div class="border">
        <nav>
      <div class="logo">
        <a href="index.php"><bold>MTAD</bold></a>
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        
        <li><a href="cart.php">Cart</a></li>
        <li><a href="faq.php" >FAQ</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <div class="buttons">
        
      <?php if($user==''){
        ?>
        <a href="login.php" class="btn">Log in /Register</a>
        <?php } else {?>
          <a href="logout.php" class="btn">Logout</a>
          <?php }?>
    </div>
    </nav>
        <header>

        <header>
      <div class="row">
        <div class="co">
          <img class="h_img" src="images/w1.jpg">
        </div>
      </div>
    </header>

    <body>

<h2>- Q: What is there to see and do in AlUlA?</h2>
<h4>Explore Hegra's UNESCO-listed tombs, marvel at Elephant Rock's unique formations, and enjoy 
serene moments in AlUla Oasis. Engage in adventure activities like desert safaris and hot air ballooning, or 
immerse yourself in cultural events during the Winter at Tantora Festival. Don't miss
 the ancient ruins of Dadan and a visit to the AlUla Museum for insights into the region's rich history and archaeology.</h4>
 
 <br><br>
 
<h2>- Q: What is the best time of year to visit AlUlA?</h2>
<h4>The best time to visit AlUla is during the winter months from November to March when temperatures are milder, making 
outdoor exploration more comfortable.Summer can be extremely hot, so it's advisable to avoid visiting during this period. Winter also
 coincides with the Winter at Tantora Festival, offering cultural events against the backdrop of AlUla's stunning landscapes.</h4>
 
  <br><br>

<h2>- Q: Is the ticket to visit AlUlA refundable?</h2>
<h4>The refund policy for tickets to visit AlUla depends on the specific ticket type, provider, and terms and conditions. It's advisable
 to check the refund policy at the time of booking to understand any applicable fees or restrictions.</h4>


 <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
 </body>
 </html>