<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
}
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="info.css">

    <style>
        body {
            color: #a52a2a;
            background-color: floralwhite;

        }

        a:link {
            color: #a52a2a;
            ;
            text-decoration: none;
        }

        body {

            background-color: floralwhite;

        }

        .row {

            left: 0;

            right: 0;

            top: 0;

            display: flex;

        }

        .co {

            left: 0;

            right: 0;

            top: 0;

            flex: 0%;

        }



        .nav {

            text-align: right;

        }
    </style>

</head>

<body lang="en">

    <div class="container">
        <div class="">
            <nav>
                <div class="logo">
                    <a href="index.php">
                        <bold>MTAD</bold>
                    </a>
                </div>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">Events</a></li>
                    
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="faq.php">FAQ</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <div class="buttons">

                    <?php if ($user == '') {
                    ?>
                        <a href="login.php" class="btn">Log in /Register</a>
                    <?php } else { ?>
                        <a href="logout.php" class="btn">Logout</a>
                    <?php } ?>
                </div>
            </nav>

            <header>
                <div class="row">
                    <div class="co">
                        <img class="h_img" src="images/w1.jpg">
                    </div>
                </div>
            </header>

            <div class="main-banner">

            </div>


            <br> <br>

            <div class="main-white-button" style="text-align:center;">

                <h1> Event details</h1>
                <br><br><br>


                <div class="event">



                    <div style="display:inline-flex; flex-wrap:wrap;">

                        <?php
                        $id = $_GET['id'];
                        $conn = mysqli_connect("localhost", "root", "", "mtad");
                        $sql = "select * from events where id =$id";
                        $result = mysqli_query($conn, $sql);
                        $row =  mysqli_fetch_assoc($result);
                        ?>
                        <div class="event_div">
                            <img src="<?php echo 'data:image/jpeg;base64,' . $row['image'] ?>" width="250" height="250" style="border-radius: 40%;" alt="">
                            <br> <br>
                            <h2><?php echo $row['name'] ?></h2>
                            <br>
                            <h3 style="color:black"><?php echo 'Ticket price: ' . $row['ticket_price'] . ' SR' ?></h3>
                            <br>
                            <h3>Number of tickets</h3>
                            <form method="post" action="add_to_cart.php">
                            <input hidden type="text" name="event_name"  value="<?php echo $row['name'] ?>"/>
                            <input hidden type="text" name="ticket_price" value="<?php echo $row['ticket_price'] ?>" />
                                <p>
                                    <input type="number" name="quantity" min=1 value="1" required lang="en" style="caret-color: transparent" onKeyDown="return false" />
                                </p>
                                <br>
                                <input type="submit" value="Add to cart" id="button" />
                                <br>

                            </form>
                        </div>


                    </div>
                    <br><br><br><br>
                   
                    <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>


</html>