<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
  $user = $_SESSION['user'];
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  extract($_POST);
  $conn = mysqli_connect("localhost", "root", "", "mtad");
  $sql = "INSERT INTO `customer`(`username`, `password`, `phone`, `gender`) VALUES ('$username','$password','$phone','$gender')";
  $result = mysqli_query($conn, $sql);

  if ($result)
    echo "<script>alert('Account created..you can login'); 
location.href='login.php'</script>";
  else {
    echo "<script>alert('Username exists');</script>";
  }
}
?>
<html>

<head>
  <title>creat</title>
  <link rel="stylesheet" type="text/css" href="info.css">
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="container">

    <nav>
      <div class="logo">
        <a href="index.php">
          <bold>MTAD</bold>
        </a>
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        
        <li><a href="cart.php">Cart</a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <div class="buttons">

        <?php if ($user == '') {
        ?>
          <a href="login.php" class="btn">Log in /Register</a>
        <?php } else { ?>
          <a href="logout.php" class="btn">Logout</a>
        <?php } ?>
      </div>
    </nav>
    </nav>

    <header>
      <div class="row">
        <div class="co">
          <img class="h_img" src="images/w1.jpg">
        </div>
      </div>
    </header>
    <br>
    <form method="post" action="signUp.php" id="login">
      <h3>Create an account</h3><br><br>
      <p> Username: </p>
      <p> <input type="text" name="username" placeholder="" required></p> <br>

      <p> Password: </p>
      <p><input type="password" name="password" placeholder="" autocomplete="new-password" required></p> <br>

      <p> Phone number: </p>
      <p> <input type="text" name="phone" minlength="10" maxlength="10" placeholder="" required></p> <br>
      <br>
      <p><label> Your gender :</label><input type="radio" value="male" name="gender" required id="info"> <label> male</label><input type="radio" value="female" name="gender" required id="info"><label> female</label></p><br>

      <input type="submit" value="Create Account" id="button">
      </form>
      <br><br>
      <p style="text-align: center;"> Already have an account ?</p><br>
      <p style="text-align: center; color: brown;">
        <a href="login.php">
          <input type="button" value="Log in" id="signUp" style="color: brown; background-color: antiquewhite;">
        </a>
      </p>
      <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>

</html>