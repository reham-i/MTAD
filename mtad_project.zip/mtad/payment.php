<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
  $user = $_SESSION['user'];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  extract($_POST);
  $conn = mysqli_connect("localhost", "root", "", "mtad");
  $sql = "SELECT  `username`, `password` FROM `customer` WHERE username = '$username' && password ='$password'";
  $result = mysqli_query($conn, $sql);

  if ($result->num_rows === 0)
    echo "<script>alert('Invalid username or password');</script>";
  else {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['user'] = $row['username'];
    header('Location: index.php');
  }
}
?>
<html>

<head>
  <title> log in</title>
  <link rel="stylesheet" type="text/css" href="info.css">
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">

    <nav>
      <div class="logo">
        <a href="index.php">
          <bold>MTAD</bold>
        </a>
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        
        <li><a href="cart.php">Cart</a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <div class="buttons">

        <?php if ($user == '') {
        ?>
          <a href="login.php" class="btn">Log in /Register</a>
        <?php } else { ?>
          <a href="logout.php" class="btn">Logout</a>
        <?php } ?>
      </div>
    </nav>
    <header>
      <div class="row">
        <div class="co">
          <img class="h_img" src="images/w1.jpg">
        </div>
      </div>
    </header>
    <br>
    <form method="post" action="checkout.php" id="login">
      <h1>Payment</h1><br> <br>
      <p> Card number: </p>
      <p> <input type="text"  placeholder="" ></p> <br>
      <p> Name on card: </p>
      <p><input type="text" name="text" placeholder=""></p> <br>
      <p> Expire date: </p>
      <p><input type="text" name="text" placeholder=""></p> <br>
      <p> CVV: </p>
      <p><input type="text" name="text" placeholder=""></p> <br>
      <input type="submit" value="Pay" id="button" />
    </form>
    <br><br>
 

    <div class="footer">
		<span>2024&copy; MTAD </span>
	</div>
</body>

</html>