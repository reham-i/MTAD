<?php
session_start();
$user = "";
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
}
if($user ==""){
    echo "<script>alert('Login to add cart'); 
    history.go(-1);</script>";
}
else{
$event_name = $_POST['event_name'];
$ticket_price = $_POST['ticket_price'];
$quantity = $_POST['quantity'];
$price = intval($ticket_price) * intval($quantity) ;
$conn = mysqli_connect("localhost", "root", "", "mtad");
$sql = "INSERT INTO `cart`(`event_name`, `quantity`, `price`,`username`) VALUES ('$event_name',$quantity,$price,'$user')";
$result = mysqli_query($conn, $sql);

if ($result)
    header('Location: cart.php');
else {
    echo "<script>alert('Add error');</script>";
}
}



?>